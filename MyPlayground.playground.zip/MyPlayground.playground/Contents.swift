import UIKit

var greeting = "Hello, playground"
print("Hii",10,12.25)

var name = "Ajay"
var grade = "B"
print("Hello, \(name)!")

var age = 26


print("""
Hello
World!
""")

print ("Hello All,\rWelcome to Swift programming")

let  welcomeMessage : String = "Hello!"
  print(welcomeMessage , "All")

print("Welcome to Swift Programming")
print("Fall 2021")
print("***********")

print("Welcome to Swift Programming" , terminator : "-" )
print("Spring 2022")

print("Hello, ")

print("you got \(grade) percentage in iOS course.")


print("The list of numbers are ")
print(1,2,3,4,5,6)

print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")

print("The new pattern is", terminator: ": ")
print(1,2,3,4,5,6)


  
var httpError = (errorCode : 420 , errorMessage : "Page not found")
                  
print(httpError)
print(httpError.errorCode , terminator : ": ")
print(httpError.errorMessage )



var origin = (x : 0 , y : 0)
var point = origin
print(point)

let city = (name : "Chicago" , population : 11,11,000)
let ( cityName ,cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)


let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

var fname = "Aj"
var lname = "Vj"
(fname , lname) = (lname , fname)
print("First Name is \(fname) and Last Name is \(lname)")



var cricketKit = ("handGloves" ,"helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
